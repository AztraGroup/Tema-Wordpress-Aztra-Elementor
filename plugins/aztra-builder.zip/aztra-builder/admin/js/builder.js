(function($){
    $(document).ready(function(){
        $('#aztra-builder-root').text('Interface do builder em desenvolvimento...');
    });
})(jQuery);
